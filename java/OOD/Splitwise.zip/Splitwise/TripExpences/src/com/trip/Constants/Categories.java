package com.trip.Constants;

public enum Categories {

	
	SNACKS,TICKETS,TAXI;
	
}
